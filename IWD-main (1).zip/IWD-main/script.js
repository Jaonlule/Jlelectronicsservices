const navlinks = document.getElementById('nav-links');

function ShowMenu(){
    navlinks.classList.add('active');
};

function hideMenu(){
    navlinks.classList.remove('active');
};